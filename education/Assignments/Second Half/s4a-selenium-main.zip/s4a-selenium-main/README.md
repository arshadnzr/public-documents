# Selenium hack on Streamlit Share

[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://share.streamlit.io/andfanilo/s4a-selenium/main/app.py)

Solving https://discuss.streamlit.io/t/issue-with-selenium-on-a-streamlit-app/11563 on Streamlit Share.

Also check Randy's version with SeleniumBase: https://discuss.streamlit.io/t/selenium-web-scraping-on-streamlit-cloud/21820/6